# M5 researcher workflow report

Invented software comparison; no human prognostic or treatment evidence.

Comparison: **complete**; reproducible pairs **7/7**.

An incomplete comparison describes successful pairs only; failures limit interpretation.

| Metric | Reported insulin U/day |
| --- | ---: |
| Baseline MAE, all eligible | 0.750749 |
| Baseline MAE, paired | 0.750749 |
| Candidate MAE, paired | 0.699199 |
| Candidate minus baseline MAE | -0.051551 |

| Participant | Candidate status | Observed | Baseline | Candidate |
| --- | --- | ---: | ---: | ---: |
| SYN004 | completed | 16.064857 | 15.113118 | 16.591239 |
| SYN008 | completed | 15.278857 | 14.834303 | 15.876161 |
| SYN012 | completed | 13.740286 | 14.555488 | 14.505020 |
| SYN016 | completed | 13.053857 | 14.276674 | 13.876977 |
| SYN024 | completed | 9.510857 | 9.795017 | 10.423174 |
| SYN028 | completed | 10.958857 | 9.516202 | 11.656131 |
| SYN032 | completed | 16.905857 | 16.999975 | 17.479117 |

## Attempt outcomes

| Participant | Attempt 1 | Attempt 2 |
| --- | --- | --- |
| SYN004 | completed: 16.591239 | completed: 16.591239 |
| SYN008 | completed: 15.876161 | completed: 15.876161 |
| SYN012 | completed: 14.505020 | completed: 14.505020 |
| SYN016 | completed: 13.876977 | completed: 13.876977 |
| SYN024 | completed: 10.423174 | completed: 10.423174 |
| SYN028 | completed: 11.656131 | completed: 11.656131 |
| SYN032 | completed: 17.479117 | completed: 17.479117 |

## Complete roster

| Participant | Split | Eligible | Exclusions | Later infusions (days) |
| --- | --- | --- | --- | --- |
| SYN001 | development | True | none | none |
| SYN002 | development | True | none | none |
| SYN003 | development | True | none | none |
| SYN004 | evaluation | True | none | none |
| SYN005 | development | False | paired_function_values_unavailable, protocol_not_collected_confirmed_graft_failure | none |
| SYN006 | development | True | none | 150 |
| SYN007 | development | True | none | none |
| SYN008 | evaluation | True | none | none |
| SYN009 | development | True | none | none |
| SYN010 | development | False | paired_function_values_unavailable, unavailable | none |
| SYN011 | development | True | none | none |
| SYN012 | evaluation | True | none | 150 |
| SYN013 | development | True | none | none |
| SYN014 | development | True | none | none |
| SYN015 | development | False | below_assay_limit, paired_function_values_unavailable | none |
| SYN016 | evaluation | True | none | none |
| SYN017 | development | True | none | none |
| SYN018 | development | True | none | 150 |
| SYN019 | development | True | none | none |
| SYN020 | evaluation | False | missing_or_ambiguous_first_infusion_y1 | none |
| SYN021 | development | True | none | none |
| SYN022 | development | True | none | none |
| SYN023 | development | True | none | none |
| SYN024 | evaluation | True | none | 150 |
| SYN025 | development | False | seven_day_diary_unverified | none |
| SYN026 | development | True | none | none |
| SYN027 | development | True | none | none |
| SYN028 | evaluation | True | none | none |
| SYN029 | development | True | none | none |
| SYN030 | development | True | none | 150 |
| SYN031 | development | True | none | none |
| SYN032 | evaluation | True | none | none |

## Source identity

Model: `invented-development-ridge`.

Source SHA-256: `a31a3868767bf5c47a2ab47fa8b33f11822b7359c26ed7b25e81d3e9c6304609`.

Frozen state SHA-256: `d2fb3d7d63f9653c45b1f7932bd5cec15c1877ac251f84fd905010f0b1ce1554`.

Training ancestry and rights are supplier declarations. Source versions, runtime and both attempts are retained in the archive.

Git revision at execution: `33926887bbe47297c98d64791d81d4246f591c98`.

Python: `CPython 3.12.15`; worker deadline: 5.0 seconds.

Tooling lock SHA-256: `d94ae2c899c72e67e77574c28c71c1b628b1929cd22438f4b95755b58e1ac03c`.

Local source bytes identify edits beyond the recorded Git revision:

- `source-contract.py`: `fc186097451491d9263a04e4600a66262f875e85148328a94bdfe72b476ba784`
- `source-report.py`: `3244b2d2e98df2f3197ef87cd8119dbfff282194ecbdc7d0575ae203aba1fe05`
- `source-run.py`: `dbe08a17bfcc4276aedc850dcaaa2287426cddfeb63f8f7c4338696ea82d5ddd`
- `source-synthetic.py`: `2cce564ecad9708310c6a0ec57236194a2b46813fe18a5ae72fb2eb637718087`
- `source-worker.py`: `5cf1f093ef4a96b7fcd66f074546dd6c10772ec91d8b7a253d8642f1c2b0bc96`
